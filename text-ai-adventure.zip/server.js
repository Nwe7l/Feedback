require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = 3000;

const starters = [
  "You wake up in a forest.",
  "You are standing at the edge of a dark cave.",
  "A storm rages as you find shelter in an abandoned cabin.",
  "You awaken in a mysterious village with no memory.",
  "You are in a space station drifting in orbit around Mars."
];

app.use(express.json());
app.use(express.static('public'));

app.get('/api/start', (req, res) => {
  const random = starters[Math.floor(Math.random() * starters.length)];
  res.json({ start: random });
});

app.post('/api/continue', async (req, res) => {
  const { story } = req.body;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'You are a text-based adventure game master. Keep it immersive and short.' },
          { role: 'user', content: story }
        ],
        temperature: 0.8
      })
    });

    const data = await response.json();
    const reply = data.choices[0].message.content.trim();
    res.json({ reply });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
