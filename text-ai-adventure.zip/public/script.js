const input = document.getElementById('input');
const output = document.getElementById('output');

let story = "";

async function getRandomStart() {
  const response = await fetch('/api/start');
  const data = await response.json();
  story = data.start + "\n";
  output.textContent = story;
}

getRandomStart();

input.addEventListener('keydown', async (e) => {
  if (e.key === 'Enter') {
    const userInput = input.value.trim();
    if (!userInput) return;

    story += `\n>> ${userInput}\n`;
    output.textContent = story;
    input.value = '';

    try {
      const response = await fetch('/api/continue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ story })
      });

      const data = await response.json();
      story += data.reply + '\n';
      output.textContent = story;
      output.scrollTop = output.scrollHeight;
    } catch (err) {
      story += "❌ Error: " + err.message + '\n';
      output.textContent = story;
    }
  }
});
